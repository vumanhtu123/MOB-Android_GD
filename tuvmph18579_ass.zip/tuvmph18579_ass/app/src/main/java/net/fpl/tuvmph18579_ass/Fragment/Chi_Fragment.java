package net.fpl.tuvmph18579_ass.Fragment;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import net.fpl.tuvmph18579_ass.Adapter.ChiViewpagerAdapter;
import net.fpl.tuvmph18579_ass.Adapter.ThuViewpagerAdapter;
import net.fpl.tuvmph18579_ass.R;

public class Chi_Fragment extends Fragment {
    TabLayout tabLayout;
    ViewPager2 viewPager2;
    ChiViewpagerAdapter adapter;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_chi,container,false);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        tabLayout = view.findViewById(R.id.tablayout_chi);
        viewPager2 = view.findViewById(R.id.viewpager_chi);
        adapter = new ChiViewpagerAdapter(this);
        viewPager2.setAdapter(adapter);

        TabLayoutMediator mediator = new TabLayoutMediator(tabLayout, viewPager2, new TabLayoutMediator.TabConfigurationStrategy() {
            @Override
            public void onConfigureTab(@NonNull TabLayout.Tab tab, int position) {
                tab.setText(position == 0 ? "Khoản Chi" : "Loại Chi");
            }
        });
        mediator.attach();
    }
}