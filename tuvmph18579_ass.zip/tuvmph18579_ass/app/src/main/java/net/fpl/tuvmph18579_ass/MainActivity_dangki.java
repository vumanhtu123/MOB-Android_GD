package net.fpl.tuvmph18579_ass;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import net.fpl.tuvmph18579_ass.DAO.DangNhapDAO;
import net.fpl.tuvmph18579_ass.DTO.DangNhap;

import java.util.List;

public class MainActivity_dangki extends AppCompatActivity {
    EditText edUser;
    EditText edPass;
    EditText edNhaplaipass;
    Button btndangky;
    Button btnNhaplai;
    DangNhapDAO dangNhapDAO;
    public static int RES = 1000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_dangki);
        //anh xa
        dangNhapDAO = new DangNhapDAO(MainActivity_dangki.this);
        edUser = findViewById(R.id.ed_nhap_Username);
        edPass = findViewById(R.id.ed_nhap_Password);
        edNhaplaipass = findViewById(R.id.ed_nhaplai_Password);
        btndangky = findViewById(R.id.btn_dangky_register);
        btnNhaplai = findViewById(R.id.btn_nhaplai);

        List<DangNhap> list= dangNhapDAO.getAll();

        btndangky.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = edUser.getText().toString();
                String pass = edPass.getText().toString();
                String repass = edNhaplaipass.getText().toString();
                DangNhap dangNhap = new DangNhap(user,pass);
                Boolean check_user = true;
                for (int i=0;i<list.size();i++){
                    if (user.matches(list.get(i).getTenDangNhap())){
                        check_user = false;
                        break;
                    }
                }
                if (user.isEmpty()||pass.isEmpty()){
                    Toast.makeText(getBaseContext(), "Khong Duoc De Trong USER and PASSWORD", Toast.LENGTH_SHORT).show();
                }else {
                    if (!pass.matches(repass)){
                        Toast.makeText(getBaseContext(), "Mat Khau Nhap Lai Khong Khop Voi Mat Khau Da Nhap", Toast.LENGTH_SHORT).show();
                    }else {
                        if (check_user==false){
                            Toast.makeText(getBaseContext(), "Tai Khoan Da Ton Tai", Toast.LENGTH_SHORT).show();
                        }else {
                            dangNhapDAO.adduser(dangNhap);
                            Toast.makeText(getBaseContext(), "Tao Tai Khoan Thanh Cong", Toast.LENGTH_SHORT).show();
                            //gui du lieu ve login
                            Intent intent = new Intent(MainActivity_dangki.this,MainActivity_login.class);
                            intent.putExtra("tk",user);
                            intent.putExtra("mk",pass);
                            setResult(MainActivity_dangki.RES,intent);
                            finish();
                        }
                    }
                }
            }
        });
    }
}