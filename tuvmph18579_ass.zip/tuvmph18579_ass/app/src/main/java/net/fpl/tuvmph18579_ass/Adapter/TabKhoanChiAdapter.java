package net.fpl.tuvmph18579_ass.Adapter;

import android.app.DatePickerDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import net.fpl.tuvmph18579_ass.DAO.KhoanChiDAO;
import net.fpl.tuvmph18579_ass.DAO.LoaiChiDAO;
import net.fpl.tuvmph18579_ass.DTO.KhoanChi;
import net.fpl.tuvmph18579_ass.DTO.LoaiChi;
import net.fpl.tuvmph18579_ass.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class TabKhoanChiAdapter extends RecyclerView.Adapter<TabKhoanChiAdapter.KhoanChiViewHolder> {
    Context context;
    ArrayList<KhoanChi> chiArrayList;
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    LoaiChiDAO loaiChiDAO;
    ArrayList<LoaiChi>list = new ArrayList<>();
    DatePickerDialog datePickerDialog;
    KhoanChiDAO khoanChiDAO;
    LoaiChi loaiChi;

    public TabKhoanChiAdapter(Context context, ArrayList<KhoanChi>chiArrayList){
        this.context = context;
        this.chiArrayList = chiArrayList;
        loaiChiDAO = new LoaiChiDAO(context);
        khoanChiDAO = new KhoanChiDAO(context);
    }
    @NonNull
    @Override
    public KhoanChiViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.tb_khoanchi_item,null);
        return new KhoanChiViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull KhoanChiViewHolder holder, int position) {
        KhoanChi khoanChi = chiArrayList.get(position);
        holder.tvTenKhoanChi.setText(khoanChi.getTenKhoanChi());
        holder.tvNoiDung.setText("Nội Dung: "+khoanChi.getNoiDung());
        holder.tvNgayChi.setText("Ngày Chi: "+simpleDateFormat.format(khoanChi.getNgayChi()));
        holder.tvSoTien.setText("Số Tiền: "+khoanChi.getSoTien()+" vnđ");
        holder.tvLoaiChi.setText("Loại Chi :"+loaiChiDAO.getTenLoaiChi(khoanChi.getIdTenLoaiChi()));

        //sửa sữ liệu
        holder.ivUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                View view = LayoutInflater.from(context).inflate(R.layout.dialog_edit_khoanchi,null);
                builder.setView(view);
                AlertDialog alertDialog= builder.create();
                //ẩn background của view-item
                alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                alertDialog.show();
                EditText edSuaTenKhoanChi = view.findViewById(R.id.ed_sua_tenkhoanchi);
                EditText edSuaNgayThuKhoanChi = view.findViewById(R.id.ed_sua_ngaythukhoanchi);
                EditText edSuaNoiDungKhoanChi = view.findViewById(R.id.ed_sua_noidungkhoanchi);
                EditText edSuaSoTienKhoanChi = view.findViewById(R.id.ed_sua_sotienkhoanchi);
                Spinner spinner = view.findViewById(R.id.sp_sua_loaichi);
                //đổ dữu liệu vào cho spinner
                list = loaiChiDAO.getAll();
                ArrayAdapter adapter_sp = new ArrayAdapter(context, android.R.layout.simple_list_item_1,list);
                spinner.setAdapter(adapter_sp);
                //chon ngay
                edSuaNgayThuKhoanChi.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Calendar calendar = Calendar.getInstance();
                        datePickerDialog = new DatePickerDialog(context, new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                                edSuaNgayThuKhoanChi.setText(year+"-"+(month+1)+"-"+dayOfMonth);
                            }
                        },calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.MONTH));
                        datePickerDialog.show();
                    }
                });
                //set lại dữ liệu khi sửa
                edSuaTenKhoanChi.setText(khoanChi.getTenKhoanChi());
                edSuaNgayThuKhoanChi.setText(simpleDateFormat.format(khoanChi.getNgayChi()));
                edSuaNoiDungKhoanChi.setText(khoanChi.getNoiDung());
                edSuaSoTienKhoanChi.setText(khoanChi.getSoTien()+"");
                int vitri = -1;
                for (int i=0;i<list.size();i++){
                    if (list.get(i).getTenLoaiChi().equalsIgnoreCase(loaiChiDAO.getTenLoaiChi(khoanChi.getIdTenLoaiChi()))){
                        vitri=i;
                        break;
                    }
                }
                spinner.setSelection(vitri);

                Button btnSua = view.findViewById(R.id.btn_sua_khoanchi);
                Button btnXoa = view.findViewById(R.id.btn_xoa_khoanchi);
                btnSua.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        khoanChi.setTenKhoanChi(edSuaTenKhoanChi.getText().toString());
                        khoanChi.setNoiDung(edSuaNoiDungKhoanChi.getText().toString());
                        khoanChi.setSoTien(Float.parseFloat(edSuaSoTienKhoanChi.getText().toString()));
                        try {
                            khoanChi.setNgayChi(simpleDateFormat.parse(edSuaNgayThuKhoanChi.getText().toString()));
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                        //set spinner
                        loaiChi = (LoaiChi) spinner.getSelectedItem();
                        khoanChi.setIdTenLoaiChi(loaiChi.getIdTenLoaiChi());
                        long result =  khoanChiDAO.update(khoanChi);
                        if(result>0){
                            //buoc cap nhap lai du lieu
                            chiArrayList.clear();
                            chiArrayList.addAll(khoanChiDAO.getAll());
                            notifyDataSetChanged();
                            Toast.makeText(view.getContext(), "Sửa Thành Công", Toast.LENGTH_SHORT).show();
                            alertDialog.dismiss();
                        }else {
                            Toast.makeText(view.getContext(), "Sửa Thất Bại", Toast.LENGTH_SHORT).show();
                            alertDialog.dismiss();
                        }
                    }
                });
                btnXoa.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        edSuaNgayThuKhoanChi.setText("");
                        edSuaNoiDungKhoanChi.setText("");
                        edSuaSoTienKhoanChi.setText("");
                        edSuaTenKhoanChi.setText("");
                    }
                });
            }
        });
        holder.ivDel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                View view = LayoutInflater.from(context).inflate(R.layout.dialog_delete,null);
                builder.setView(view);
                AlertDialog alertDialog= builder.create();
                alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                alertDialog.show();
                Button btn_delete = view.findViewById(R.id.btn_ok_delete);
                btn_delete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        long result=khoanChiDAO.delete(khoanChi.getIdKhoanChi());
                        if(result>0){
                            //buoc cap nhap lai du lieu
                            chiArrayList.clear();
                            chiArrayList.addAll(khoanChiDAO.getAll());
                            notifyDataSetChanged();
                            Toast.makeText(view.getContext(), "Xóa Thành Công", Toast.LENGTH_SHORT).show();
                            alertDialog.dismiss();
                        }else {
                            Toast.makeText(view.getContext(), "Xóa Thất Bại", Toast.LENGTH_SHORT).show();
                            alertDialog.dismiss();

                        }
                    }
                });
            }
        });
    }

    @Override
    public int getItemCount() {
        return chiArrayList.size();
    }

    public class KhoanChiViewHolder extends RecyclerView.ViewHolder{
        //anh xa
        TextView tvTenKhoanChi, tvNoiDung, tvSoTien, tvNgayChi, tvLoaiChi;
        ImageView ivDel, ivUp;

        public KhoanChiViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTenKhoanChi = itemView.findViewById(R.id.tv_tenkhoanchi);
            tvNoiDung = itemView.findViewById(R.id.tv_noidung_khoanchi);
            tvSoTien = itemView.findViewById(R.id.tv_sotien_khoanchi);
            tvNgayChi = itemView.findViewById(R.id.tv_ngaychi_khoanchi);
            tvLoaiChi = itemView.findViewById(R.id.tv_loaichi_khoanchi);
            ivDel = itemView.findViewById(R.id.iv_delete_khoanchi);
            ivUp = itemView.findViewById(R.id.iv_edit_khoanchi);
        }
    }
}
