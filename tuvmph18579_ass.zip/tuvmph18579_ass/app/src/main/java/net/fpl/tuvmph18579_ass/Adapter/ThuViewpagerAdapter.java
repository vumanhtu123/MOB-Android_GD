package net.fpl.tuvmph18579_ass.Adapter;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Lifecycle;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import net.fpl.tuvmph18579_ass.Fragment.TabKhoanThuFragment;
import net.fpl.tuvmph18579_ass.Fragment.TabLoaiThuFragment;
import net.fpl.tuvmph18579_ass.Fragment.Thu_Fragment;

public class ThuViewpagerAdapter extends FragmentStateAdapter {
    int cout = 2;
    public ThuViewpagerAdapter(@NonNull Fragment fragment) {
        super(fragment);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position){
            case 0:
                return new TabKhoanThuFragment();
            case 1:
                return new TabLoaiThuFragment();
        }
        return null;
    }

    @Override
    public int getItemCount() {
        return cout;
    }
}
