package net.fpl.tuvmph18579_ass.Fragment;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;

import net.fpl.tuvmph18579_ass.DAO.KhoanChiDAO;
import net.fpl.tuvmph18579_ass.DAO.KhoanThuDAO;
import net.fpl.tuvmph18579_ass.DTO.KhoanChi;
import net.fpl.tuvmph18579_ass.DTO.KhoanThu;
import net.fpl.tuvmph18579_ass.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class ThongKeFragment extends Fragment {
    Button btnNgaybatdau;
    Button btnNgayketthuc;
    Button btnKetqua;
    TextView tvTongthu;
    TextView tvSotientongthu;
    TextView tvTongchi;
    TextView tvSotientongchi;
    KhoanChiDAO khoanChiDAO;
    KhoanThuDAO khoanThuDAO;
    float tongthu=0,tongchi=0;
    DatePickerDialog datePickerDialog;
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_thong_ke, container, false);

        khoanChiDAO = new KhoanChiDAO(getContext());
        khoanThuDAO = new KhoanThuDAO(getContext());
        btnNgaybatdau = (Button) view.findViewById(R.id.btn_ngaybatdau);
        btnNgayketthuc = (Button) view.findViewById(R.id.btn_ngayketthuc);
        btnKetqua = (Button) view.findViewById(R.id.btn_ketqua);
        tvTongthu = (TextView) view.findViewById(R.id.tv_tongthu);
        tvSotientongthu = (TextView) view.findViewById(R.id.tv_sotientongthu);
        tvTongchi = (TextView) view.findViewById(R.id.tv_tongchi);
        tvSotientongchi = (TextView) view.findViewById(R.id.tv_sotientongchi);
        //tông thu chi
        ArrayList<KhoanChi> listchi =khoanChiDAO.getAll();
        for (int i= 0;i<listchi.size();i++){
            tongchi = tongchi + listchi.get(i).getSoTien();
        }
        tvSotientongchi.setText(tongchi+" VNĐ");


        ArrayList<KhoanThu> listthu =khoanThuDAO.getAll();
        for (int i= 0;i<listthu.size();i++){
            tongthu = tongthu + listthu.get(i).getSoTien();
        }
        tvSotientongthu.setText(tongthu+" VNĐ");

        //chọn ngày
        btnNgaybatdau.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                datePickerDialog = new DatePickerDialog(getContext(), new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        btnNgaybatdau.setText(year+"-"+(month+1)+"-"+dayOfMonth);
                    }
                },calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH));
                datePickerDialog.show();
            }
        });

        btnNgayketthuc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                datePickerDialog = new DatePickerDialog(getContext(), new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        btnNgayketthuc.setText(year+"-"+(month+1)+"-"+dayOfMonth);
                    }
                },calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH),calendar.get(Calendar.DAY_OF_MONTH));
                datePickerDialog.show();
            }
        });
        //ket qua

        btnKetqua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Tính tiền theo ngày
                float chi_THEONGAY = 0;
                float thu_THEONGAY = 0;
                String ngaybatdau=btnNgaybatdau.getText().toString();
                String ngayketthuc=btnNgayketthuc.getText().toString();

                //chi
                for (int i= 0;i<listchi.size();i++){
                    try {
                        if (listchi.get(i).getNgayChi().compareTo(simpleDateFormat.parse(ngaybatdau))>=0 && listchi.get(i).getNgayChi().compareTo(simpleDateFormat.parse(ngayketthuc))<=0 ){
                            chi_THEONGAY = chi_THEONGAY + listchi.get(i).getSoTien();
                        }
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }

                }

                //thu
                for (int i= 0;i<listthu.size();i++){
                    try {
                        if (listthu.get(i).getNgayThu().compareTo(simpleDateFormat.parse(ngaybatdau))>=0 && listthu.get(i).getNgayThu().compareTo(simpleDateFormat.parse(ngayketthuc))<=0 ){
                            thu_THEONGAY = thu_THEONGAY + listthu.get(i).getSoTien();
                        }
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }

                }

                tvSotientongchi.setText(chi_THEONGAY+" VNĐ");
                tvSotientongthu.setText(thu_THEONGAY+" VNĐ");

            }
        });
        return view;
    }
}