package net.fpl.tuvmph18579_ass.Adapter;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import net.fpl.tuvmph18579_ass.Fragment.TabKhoanChiFragment;
import net.fpl.tuvmph18579_ass.Fragment.TabLoaiChiFragment;

public class ChiViewpagerAdapter extends FragmentStateAdapter {
    int cout = 2;
    public ChiViewpagerAdapter(@NonNull Fragment fragment) {
        super(fragment);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position){
            case 0:
                return new TabKhoanChiFragment();
                case 1:
                    return new TabLoaiChiFragment();
        }
        return null;
    }

    @Override
    public int getItemCount() {
        return cout;
    }
}
