package net.fpl.tuvmph18579_ass.DbHelper;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class MyDbHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "quanlythuchi";
    public static final int DB_VERSION = 1;
    public MyDbHelper(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String add_tb_loaichi = "CREATE TABLE tb_loaichi (idTenLoaiChi INTEGER PRIMARY KEY AUTOINCREMENT, tenLoaiChi TEXT NOT NULL)";
        db.execSQL(add_tb_loaichi);
        //table loai chi

        String add_tb_loaithu = "CREATE TABLE tb_loaithu (idTenLoaiThu INTEGER PRIMARY KEY AUTOINCREMENT, tenLoaiThu TEXT NOT NULL)";
        db.execSQL(add_tb_loaithu);
        //table loai thu

        String add_tb_khoanchi = "CREATE TABLE tb_khoanchi (idKhoanChi INTEGER PRIMARY KEY AUTOINCREMENT, idTenLoaiChi INTEGER NOT NULL REFERENCES tb_loaichi(idTenLoaiChi), tenKhoanChi TEXT NOT NULL, noiDung TEXT NOT NULL, soTien FLOAT, ngayChi DATE)";
        db.execSQL(add_tb_khoanchi);
        //table khoan chi

        String add_tb_khoanthu = "CREATE TABLE tb_khoanthu (idKhoanThu INTEGER PRIMARY KEY AUTOINCREMENT, idTenLoaiThu INTEGER NOT NULL REFERENCES tb_loaithu(idTenLoaiThu), tenKhoanThu TEXT NOT NULL, noiDung TEXT NOT NULL, soTien FLOAT, ngayThu DATE)";
        db.execSQL(add_tb_khoanthu);
        //table khoan thu

        //TABLE TAIKHOAN DANG NHAP
        String sql_cr_tb_account = "CREATE TABLE tb_account (taikhoan text PRIMARY KEY, passwrod text)";
        db.execSQL(sql_cr_tb_account);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
