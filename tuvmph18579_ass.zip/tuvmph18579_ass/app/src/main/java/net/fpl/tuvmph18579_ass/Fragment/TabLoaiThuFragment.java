package net.fpl.tuvmph18579_ass.Fragment;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import net.fpl.tuvmph18579_ass.Adapter.TabLoaiThuAdapter;
import net.fpl.tuvmph18579_ass.DAO.LoaiThuDAO;
import net.fpl.tuvmph18579_ass.DTO.LoaiThu;
import net.fpl.tuvmph18579_ass.R;

import java.util.ArrayList;

public class TabLoaiThuFragment extends Fragment {
    RecyclerView recyclerView;
    LoaiThuDAO loaiThuDAO;
    TabLoaiThuAdapter thuAdapter;
    ArrayList<LoaiThu>list;
    FloatingActionButton btnadd;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_tab_loai_thu,container,false);
        recyclerView = view.findViewById(R.id.recyclerView_loaithu);
        btnadd = view.findViewById(R.id.fab_addloaithu);
        loaiThuDAO = new LoaiThuDAO(getContext());
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        list = new ArrayList<>();
        list = loaiThuDAO.getAll();
        thuAdapter = new TabLoaiThuAdapter(getContext(),list);
        recyclerView.setAdapter(thuAdapter);
        btnadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                add();
            }
        });
        return view;
    }
    public void add(){
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_add_loaithu,null);
        builder.setView(view);
        AlertDialog alertDialog = builder.create();
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        alertDialog.show();
        EditText ednoidung = view.findViewById(R.id.ed_them_tenloaithu);
        Button them = view.findViewById(R.id.btn_them_loaithu);
        Button huy = view.findViewById(R.id.btn_huy_loaithu);
        them.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LoaiThu loaiThu = new LoaiThu();
                loaiThu.setTenLoaiThu(ednoidung.getText().toString());
                if (ednoidung.getText().toString().isEmpty()){
                    Toast.makeText(getContext(), "Không Được Để Trống Nội Dung", Toast.LENGTH_SHORT).show();
                    return;
                }
                long res = loaiThuDAO.insert(loaiThu);
                if (res>0){
                    //cap nhap lai du lieu
                    list.clear();
                    list.addAll(loaiThuDAO.getAll());
                    thuAdapter.notifyDataSetChanged();
                    Toast.makeText(getContext(), "Thêm Thành Công", Toast.LENGTH_SHORT).show();
                    alertDialog.dismiss();
                }else {
                    Toast.makeText(getContext(), "Thêm Thất Bại", Toast.LENGTH_SHORT).show();
                    alertDialog.dismiss();
                }
            }
        });
        huy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ednoidung.setText("");
            }
        });
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }
}