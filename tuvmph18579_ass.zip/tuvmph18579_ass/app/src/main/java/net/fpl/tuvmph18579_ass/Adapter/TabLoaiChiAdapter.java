package net.fpl.tuvmph18579_ass.Adapter;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import net.fpl.tuvmph18579_ass.DAO.KhoanChiDAO;
import net.fpl.tuvmph18579_ass.DAO.KhoanThuDAO;
import net.fpl.tuvmph18579_ass.DAO.LoaiChiDAO;
import net.fpl.tuvmph18579_ass.DTO.KhoanChi;
import net.fpl.tuvmph18579_ass.DTO.KhoanThu;
import net.fpl.tuvmph18579_ass.DTO.LoaiChi;
import net.fpl.tuvmph18579_ass.R;

import java.util.ArrayList;

public class TabLoaiChiAdapter extends RecyclerView.Adapter<TabLoaiChiAdapter.LoaiChiViewHolder> {
    ArrayList<LoaiChi>list;
    ArrayList<KhoanThu> thuArrayList = new ArrayList<>();
    LoaiChiDAO loaiChiDAO;
    KhoanThuDAO khoanThuDAO;
    Context context;
    public TabLoaiChiAdapter(Context context,ArrayList<LoaiChi>list){
        this.list = list;
        this.context = context;
        loaiChiDAO = new LoaiChiDAO(context);
        khoanThuDAO = new KhoanThuDAO(context);
    }
    @NonNull
    @Override
    public LoaiChiViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.tb_loaichi_item,parent,false);
        return new LoaiChiViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull LoaiChiViewHolder holder, int position) {
        LoaiChi loaiChi = list.get(position);
        holder.tv_name.setText(loaiChi.getTenLoaiChi());
        //sửa dữ liệu
        holder.iv_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                View view = LayoutInflater.from(context).inflate(R.layout.dialog_edit_loaichi,null);
                builder.setView(view);
                AlertDialog alertDialog= builder.create();
                //ẩn background của view-item
                alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                alertDialog.show();
                EditText edSuaLoaiChi = view.findViewById(R.id.ed_sua_tenloaichi);
                edSuaLoaiChi.setText(loaiChi.getTenLoaiChi());
                Button btnSua = view.findViewById(R.id.btn_sua_loaichi);
                Button btnXoa = view.findViewById(R.id.btn_xoa_loaichi);
                btnSua.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        loaiChi.setTenLoaiChi(edSuaLoaiChi.getText().toString());
                        long result =  loaiChiDAO.update(loaiChi);
                        if(result>0){
                            //buoc cap nhap lai du lieu
                            list.clear();
                            list.addAll(loaiChiDAO.getAll());
                            notifyDataSetChanged();
                            Toast.makeText(view.getContext(), "Sửa Thành Công", Toast.LENGTH_SHORT).show();
                            alertDialog.dismiss();
                        }else {
                            Toast.makeText(view.getContext(), "Sửa Thất Bại", Toast.LENGTH_SHORT).show();
                            alertDialog.dismiss();
                        }
                    }
                });
                btnXoa.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        edSuaLoaiChi.setText("");
                    }
                });
            }
        });
        //Xóa Dữ Liệu
        holder.iv_del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                View view = LayoutInflater.from(context).inflate(R.layout.dialog_delete,null);
                builder.setView(view);
                AlertDialog alertDialog= builder.create();
                alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                alertDialog.show();
                Button btn_delete = view.findViewById(R.id.btn_ok_delete);
                btn_delete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //check sem dữ liệu con đã bị xóa chưa
                        ArrayList<LoaiChi> list  =loaiChiDAO.checkGetIDLoaiChi(loaiChi.getIdTenLoaiChi());
                        Log.e("xxx", "onClick: "+list.size() );
                        if (list.size()>0){
                            AlertDialog.Builder builder = new AlertDialog.Builder(context);
                            View view = LayoutInflater.from(context).inflate(R.layout.dialog_e,null);
                            builder.setView(view);
                            AlertDialog alertDialog2= builder.create();
                            alertDialog2.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                            alertDialog2.show();
                            Button btn_e = view.findViewById(R.id.btn_e);
                            btn_e.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    alertDialog2.dismiss();
                                    alertDialog.dismiss();
                                }
                            });
                            return;
                        }

                        long result=loaiChiDAO.delete(loaiChi.getIdTenLoaiChi());
                        if(result>0){
                            //buoc cap nhap lai du lieu
                            list.clear();
                            list.addAll(loaiChiDAO.getAll());
                            notifyDataSetChanged();
                            Toast.makeText(view.getContext(), "Xóa Thành Công", Toast.LENGTH_SHORT).show();
                            alertDialog.dismiss();


                        }else {
                            Toast.makeText(view.getContext(), "Xóa Thất Bại", Toast.LENGTH_SHORT).show();
                            alertDialog.dismiss();

                        }
                    }
                });
            }
        });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }
    class LoaiChiViewHolder extends RecyclerView.ViewHolder {
        public TextView tv_name;
        public ImageView iv_del, iv_up;
        public LoaiChiViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_name = itemView.findViewById(R.id.tv_noidungloaichi);
            iv_up = itemView.findViewById(R.id.iv_edit_loaichi);
            iv_del = itemView.findViewById(R.id.iv_delete_loaichi);
        }
    }
}
