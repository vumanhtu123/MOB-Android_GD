package net.fpl.tuvmph18579_ass.DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import net.fpl.tuvmph18579_ass.DTO.KhoanThu;
import net.fpl.tuvmph18579_ass.DbHelper.MyDbHelper;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class KhoanThuDAO {
    //khai bao database
    MyDbHelper myDbHelper;
    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
    public KhoanThuDAO(Context context){
        myDbHelper = new MyDbHelper(context);
    }
    //danh sach
    public ArrayList<KhoanThu>getAll(){
        SQLiteDatabase sqLiteDatabase = myDbHelper.getReadableDatabase();
        ArrayList<KhoanThu> list = new ArrayList<>();
        String SELECT = "SELECT * FROM " +KhoanThu.TB_NAME;
        //tao con tro
        Cursor cursor = sqLiteDatabase.rawQuery(SELECT,null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()){
            int id1 = cursor.getInt(0);
            int id2 = cursor.getInt(1);
            String name = cursor.getString(2);
            String noidung = cursor.getString(3);
            float money = cursor.getFloat(4);
            Date date = null;
            try {
                date = format.parse(cursor.getString(5));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            KhoanThu khoanThu = new KhoanThu(id1,id2,name,noidung,money,date);
            list.add(khoanThu);
            cursor.moveToNext();
        }
        cursor.close();
        myDbHelper.close();
        return list;
    }
    //add
    public long insert(KhoanThu khoanThu){
        SQLiteDatabase sqLiteDatabase = myDbHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(KhoanThu.COL_NAME_ID_LoaiThu,khoanThu.getIdTenLoaiThu());
        contentValues.put(KhoanThu.COL_NAME_TEN,khoanThu.getTenKhoanThu());
        contentValues.put(KhoanThu.COL_NAME_NOIDUNG,khoanThu.getNoiDung());
        contentValues.put(KhoanThu.COL_NAME_SOTIEN,khoanThu.getSoTien());
        contentValues.put(KhoanThu.COL_NAME_NGAYTHU,format.format(khoanThu.getNgayThu()));
        long res = sqLiteDatabase.insert(KhoanThu.TB_NAME,null,contentValues);
        return res;
    }
    //update
    public long update(KhoanThu khoanThu){
        SQLiteDatabase sqLiteDatabase = myDbHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(KhoanThu.COL_NAME_ID_LoaiThu,khoanThu.getIdTenLoaiThu());
        contentValues.put(KhoanThu.COL_NAME_TEN,khoanThu.getTenKhoanThu());
        contentValues.put(KhoanThu.COL_NAME_NOIDUNG,khoanThu.getNoiDung());
        contentValues.put(KhoanThu.COL_NAME_SOTIEN,khoanThu.getSoTien());
        contentValues.put(KhoanThu.COL_NAME_NGAYTHU,format.format(khoanThu.getNgayThu()));
        long res = sqLiteDatabase.update(KhoanThu.TB_NAME,contentValues,"idKhoanThu = ? ",new String[]{String.valueOf(khoanThu.getIdKhoanThu())});
        return res;
    }
    //delete
    public long delete(int id){
        SQLiteDatabase sqLiteDatabase = myDbHelper.getWritableDatabase();
        long res = sqLiteDatabase.delete(KhoanThu.TB_NAME,"idKhoanThu = " + id,null);
        return res;
    }

    public ArrayList<KhoanThu> getKhoanThuTheoDK(String sql, String... a) {

        SQLiteDatabase db = myDbHelper.getReadableDatabase();
        ArrayList<KhoanThu> khoanThuArrayList = new ArrayList<>();
        Cursor cursor =db.rawQuery(sql,a);
        //dua con tro ve dau ket qua
        cursor.moveToFirst();
        while (!cursor.isAfterLast()){
            int id1 = cursor.getInt(0);
            int id2 = cursor.getInt(1);
            String ten = cursor.getString(2);
            String noiDung = cursor.getString(3);
            float soTien = cursor.getFloat(4);
            Date ngay = null;
            try {
                ngay = format.parse(cursor.getString(5));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            KhoanThu khoanThu = new KhoanThu(id2,id1,ten,noiDung,soTien,ngay);
            khoanThuArrayList.add(khoanThu);
            cursor.moveToNext();
        }
        cursor.close();//dong con tro
        db.close();//dong csdl
        return khoanThuArrayList;
    }
}
