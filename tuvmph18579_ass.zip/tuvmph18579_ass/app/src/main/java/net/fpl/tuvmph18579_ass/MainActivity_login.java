package net.fpl.tuvmph18579_ass;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import net.fpl.tuvmph18579_ass.DAO.DangNhapDAO;
import net.fpl.tuvmph18579_ass.DTO.DangNhap;

public class MainActivity_login extends AppCompatActivity {
    private long Pressed;
    private EditText txtUser,txtPass;
    private Button btnDangki,btnDangnhap;
    DangNhapDAO dangNhapDAO;
    private CheckBox checkRemember;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_login);
        dangNhapDAO = new DangNhapDAO(MainActivity_login.this);
        //anh xa
        innit();
        //load data
        loaddata();
        btnDangnhap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = txtUser.getText().toString();
                String pass = txtPass.getText().toString();
                Boolean checker = checkRemember.isChecked();
                DangNhap dangNhap = new DangNhap(user,pass);
                if (dangNhapDAO.checklogin(dangNhap)){
                    savedata(user,pass,checker);
                    Toast.makeText(getBaseContext(), "Dang Nhap Thanh Cong", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity_login.this,MainActivity.class);
                    startActivity(intent);
                }else {
                    Toast.makeText(getBaseContext(), "Dang Nhap That Bai", Toast.LENGTH_SHORT).show();
                }
            }
        });
        btnDangki.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity_login.this,MainActivity_dangki.class);
//                startActivity(intent);
                startActivityForResult(intent,MainActivity_dangki.RES);
            }
        });
    }
    public void savedata(String user, String passw, boolean check){
        SharedPreferences sharedPreferences = getSharedPreferences("Data.dat",MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        if (check==true){
            editor.putString("username",user);
            editor.putString("password",passw);
            editor.putBoolean("checker",check);
        }else {
            editor.clear();
        }
        editor.commit(); // xac nhan da luu thong tin
    }

    public void innit(){
        txtPass = findViewById(R.id.txtPassword);
        txtUser = findViewById(R.id.txtUsername);
        checkRemember = findViewById(R.id.checkRemeber);
        btnDangki = findViewById(R.id.btn_dangky);
        btnDangnhap = findViewById(R.id.btn_dangnhap);
    }
    //output du lieu
    public void loaddata(){
        SharedPreferences sharedPreferences = getSharedPreferences("Data.dat",MODE_PRIVATE);
        Boolean check = sharedPreferences.getBoolean("checker",false);
        if (check){
            txtUser.setText(sharedPreferences.getString("username",""));
            txtPass.setText(sharedPreferences.getString("password",""));
            checkRemember.setChecked(check);
        }
    }
    //ham lay data tu ben dang ki
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode==MainActivity_dangki.RES){
            String us = data.getStringExtra("tk");
            String pw = data.getStringExtra("mk");
            txtUser.setText(us);
            txtPass.setText(pw);
        }
    }

    @Override
    public void onBackPressed() {
        if (Pressed+2000>System.currentTimeMillis()){
            Toast.makeText(getBaseContext(), "", Toast.LENGTH_SHORT).show();
            super.onBackPressed();
        }else {
            Toast.makeText(getBaseContext(), "An hai lan de thoat ung dung", Toast.LENGTH_SHORT).show();
        }
        Pressed=System.currentTimeMillis();
    }
}