package net.fpl.tuvmph18579_ass.Fragment;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import net.fpl.tuvmph18579_ass.Adapter.TabKhoanThuAdapter;
import net.fpl.tuvmph18579_ass.DAO.KhoanThuDAO;
import net.fpl.tuvmph18579_ass.DAO.LoaiThuDAO;
import net.fpl.tuvmph18579_ass.DTO.KhoanThu;
import net.fpl.tuvmph18579_ass.DTO.LoaiThu;
import net.fpl.tuvmph18579_ass.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class TabKhoanThuFragment extends Fragment {
    RecyclerView recyclerView;
    TabKhoanThuAdapter khoanThuAdapter;
    KhoanThuDAO khoanThuDAO;
    LoaiThuDAO loaiThuDAO;
    ArrayList<KhoanThu>list;
    FloatingActionButton fbkhoanthu;
    ArrayList<LoaiThu>list1 = new ArrayList<>();
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    DatePickerDialog datePickerDialog;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_tab_khoan_thu,container,false);
        recyclerView = view.findViewById(R.id.recyclerView_khoanthu);
        fbkhoanthu = view.findViewById(R.id.fab_addkhoanthu);
        khoanThuDAO = new KhoanThuDAO(getContext());
        loaiThuDAO = new LoaiThuDAO(getContext());
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        list = new ArrayList<>();
        list = khoanThuDAO.getAll();
        khoanThuAdapter = new TabKhoanThuAdapter(getContext(),list);
        recyclerView.setAdapter(khoanThuAdapter);
        fbkhoanthu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addDialog();
            }
        });
        return view;
    }
    public void addDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_add_khoanthu,null);
        builder.setView(view);
        AlertDialog alertDialog = builder.create();
        //tran vien
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        alertDialog.show();
        //anh xa
        EditText edthemkhoanthu = view.findViewById(R.id.ed_them_tenkhoanthu);
        EditText ednoidungkhoanthu = view.findViewById(R.id.ed_them_noidungkhoanthu);
        EditText edngaythu = view.findViewById(R.id.ed_them_ngaythukhoanthu);
        EditText edsotien = view.findViewById(R.id.ed_them_sotienkhoanthu);
        Spinner spnthemloaithu = view.findViewById(R.id.sp_them_loaithu);
        //do du lieu vao spinner
        list1 = loaiThuDAO.getAll();
        ArrayAdapter adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1,list1);
        spnthemloaithu.setAdapter(adapter);
        //chon ngay
        edngaythu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                datePickerDialog = new DatePickerDialog(getContext(), new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        edngaythu.setText(year+"-"+(month+1)+"-"+dayOfMonth);
                    }
                },calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH),
                        calendar.get(Calendar.DAY_OF_MONTH));
                datePickerDialog.show();
            }
        });
        Button themkhoanthu = view.findViewById(R.id.btn_them_khoanthu);
        Button huy = view.findViewById(R.id.btn_huy_khoanthu);
        themkhoanthu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edthemkhoanthu.getText().toString().isEmpty()||ednoidungkhoanthu.getText().toString().isEmpty()||edngaythu.getText().toString().isEmpty()||
                edsotien.getText().toString().isEmpty()
                ){
                    Toast.makeText(getContext(), "Không Được Để Trống", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (list1.size()<=0){
                    Toast.makeText(getContext(), "Loại Thu Chưa Có Dữ Liệu ! \n Mời Bạn Nhập Loại Thu Trước", Toast.LENGTH_SHORT).show();
                    return;
                }
                KhoanThu khoanThu = new KhoanThu();
                khoanThu.setTenKhoanThu(edthemkhoanthu.getText().toString());
                khoanThu.setNoiDung(ednoidungkhoanthu.getText().toString());
                try {
                    khoanThu.setNgayThu(simpleDateFormat.parse(edngaythu.getText().toString()));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                khoanThu.setSoTien(Float.parseFloat(edsotien.getText().toString()));
                LoaiThu loaiThu = (LoaiThu) spnthemloaithu.getSelectedItem();
                khoanThu.setIdTenLoaiThu(loaiThu.getIdTenLoaiThu());
                long res = khoanThuDAO.insert(khoanThu);
                if (res>0){
                    //cap nhap lai du lieu
                    list.clear();
                    list.addAll(khoanThuDAO.getAll());
                    adapter.notifyDataSetChanged();
                    Toast.makeText(getContext(), "Thêm Thành Công", Toast.LENGTH_SHORT).show();
                    alertDialog.dismiss();
                }else {
                    Toast.makeText(getContext(), "Thêm Thất Bại", Toast.LENGTH_SHORT).show();
                    alertDialog.dismiss();
                }
            }
        });
        huy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edngaythu.setText("");
                ednoidungkhoanthu.setText("");
                edsotien.setText("");
                edthemkhoanthu.setText("");
            }
        });
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }
}