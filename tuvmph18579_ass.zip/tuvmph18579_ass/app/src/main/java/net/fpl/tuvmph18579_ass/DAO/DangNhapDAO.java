package net.fpl.tuvmph18579_ass.DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import net.fpl.tuvmph18579_ass.DTO.DangNhap;
import net.fpl.tuvmph18579_ass.DbHelper.MyDbHelper;

import java.util.ArrayList;
import java.util.List;

public class DangNhapDAO {
    MyDbHelper myDbHelper;
    public DangNhapDAO(Context context){
        myDbHelper = new MyDbHelper(context);
    }
    public boolean checklogin(DangNhap dangNhap){
        SQLiteDatabase database = myDbHelper.getReadableDatabase();
        String select = "SELECT * FROM tb_account WHERE taikhoan=? AND passwrod =?";
        Cursor cursor = database.rawQuery(select,new String[]{dangNhap.getTenDangNhap(),dangNhap.getMatKhau()});
        cursor.moveToFirst();
        if (cursor.getCount()<0){
            return false;
        }else {
            return true;
        }
    }
    public long adduser(DangNhap dangNhap){
        SQLiteDatabase sqLiteDatabase = myDbHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("taikhoan",dangNhap.getTenDangNhap());
        contentValues.put("passwrod",dangNhap.getMatKhau());
        long res = sqLiteDatabase.insert("tb_account",null,contentValues);
        return res;
    }
    public List<DangNhap> getAll(){
        List<DangNhap> list = new ArrayList<>();
        SQLiteDatabase db = myDbHelper.getReadableDatabase();
        String SELECT = "SELECT * FROM tb_account";
        Cursor cursor = db.rawQuery(SELECT,null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()){
            String u = cursor.getString(0);
            String p = cursor.getString(1);
            DangNhap dangNhap =  new DangNhap(u,p);
            list.add(dangNhap);
            cursor.moveToNext();
        }
        cursor.close();
        db.close();
        return  list;
    }
}
